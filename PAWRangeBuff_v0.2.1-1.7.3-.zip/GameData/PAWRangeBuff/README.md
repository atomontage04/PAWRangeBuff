# PAWRangeBuff
This KSP mod increases the maximum distance at which kerbanauts are able to open Part Action Window menus while being EVA.

The modifier applies to any PAW item, even modded ones (at least it tries to).

As of now, the formula is still a subject to change. For now, the modifier takes into account the largest attach node of the part you right-clicked on.

## SETTINGS
See `Settings.cfg` in the mod directory.

## INSTALLATION
Just unzip the contents of a release archive to the KSP directory.

### Thanks to
This mod uses [KSPDev Utils & Release Tools](https://forum.kerbalspaceprogram.com/index.php?/topic/150786-minimum-ksp-version-18-kspdev-logconsole-v21-utils-v22-releasetools-v11-localizationtool-v19/) created by IgorZ.
